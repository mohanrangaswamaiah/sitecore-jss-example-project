import { Component, OnInit, Input } from '@angular/core';
import { ComponentRendering } from '@sitecore-jss/sitecore-jss-angular';

@Component({
  selector: 'app-sitecore-first-component',
  templateUrl: './sitecore-first-component.component.html',
  styleUrls: ['./sitecore-first-component.component.css']
})
export class SitecoreFirstComponentComponent implements OnInit {
  @Input() rendering: ComponentRendering;

  constructor() { }

  ngOnInit() {
    // remove this after implementation is done
    console.log('SitecoreFirstComponent component initialized with component data', this.rendering);
  }
}
