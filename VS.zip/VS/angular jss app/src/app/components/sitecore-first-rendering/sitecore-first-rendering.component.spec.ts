import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { JssModule } from '@sitecore-jss/sitecore-jss-angular';
import { SitecoreFirstRenderingComponent } from './sitecore-first-rendering.component';

describe('SitecoreFirstRenderingComponent', () => {
  let component: SitecoreFirstRenderingComponent;
  let fixture: ComponentFixture<SitecoreFirstRenderingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ JssModule.forRoot() ],
      declarations: [ SitecoreFirstRenderingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SitecoreFirstRenderingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
