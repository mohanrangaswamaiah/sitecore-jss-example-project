# CustomGraphQLSchema
This code project includes a custom GraphQL schema defined for Sitecore
This includes .Net project for ProductionSchemaProvider and a Sitecore patch config which needs to be added into AppConfig/include folder
