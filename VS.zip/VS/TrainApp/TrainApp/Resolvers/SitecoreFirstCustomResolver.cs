﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using Sitecore.Configuration;
using Sitecore.LayoutService.Configuration;
using Sitecore.LayoutService.ItemRendering.ContentsResolvers;
using System;
using System.Collections.Generic;
using System.Text;
using Sitecore.Mvc.Presentation;

namespace TrainApp.Resolvers
{
    public class SitecoreFirstCustomResolver : RenderingContentsResolver
    {
        public string contextItem = "scContextItem";
        public string contextDB = "scContextDatabase";
        public string returnUrl = "returnUrl";
        public override object ResolveContents(Rendering rendering, IRenderingConfiguration renderingConfig)
        {
            var jsettings = new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() };

            var item = Factory.GetDatabase("master").GetItem("/sitecore/content/angular-app-four/home/sc-first");
            var jsonObject = base.ProcessItem(item, rendering, renderingConfig);

            string itemName = rendering.Item.DisplayName;
            jsonObject.Add(contextItem, JToken.Parse(JsonConvert.SerializeObject(itemName, jsettings)));

            string dbName = Sitecore.Context.Database.Name;
            jsonObject.Add(contextDB, JToken.Parse(JsonConvert.SerializeObject(dbName, jsettings)));
                     
            var retUrl = Sitecore.Context.Request.QueryString["retUrl"];
            jsonObject.Add(returnUrl, JToken.Parse(JsonConvert.SerializeObject(retUrl, jsettings)));

            return jsonObject;
        }

    }
}
