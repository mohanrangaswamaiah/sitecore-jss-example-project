﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using Sitecore.Configuration;
using Sitecore.LayoutService.Configuration;
using Sitecore.LayoutService.ItemRendering.ContentsResolvers;
using Sitecore.Mvc.Presentation;

namespace TrainApp.Resolvers
{
    public class SitecoreContextDataContentResolver : RenderingContentsResolver
    {
        public  string contextUser = "scContextUser";
        public string contextDB = "scContextDatabase";
        public string userName = "userName";
        public string returnUrl = "returnUrl";
        public override object ResolveContents(Rendering rendering, IRenderingConfiguration renderingConfig)
        {
            var jsettings = new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() };

            var item = Factory.GetDatabase("master").GetItem("/sitecore/content/angular-app-four/home/styleguide/custom-route-type");
            var jsonObject = base.ProcessItem(item, rendering, renderingConfig);

            string dbName = Sitecore.Context.Database.Name;
            jsonObject.Add(contextDB, JToken.Parse(JsonConvert.SerializeObject(dbName, jsettings)));

            var usrName = Sitecore.Context.GetUserName();
            jsonObject.Add(userName, JToken.Parse(JsonConvert.SerializeObject(usrName, jsettings)));

            var scUser = Sitecore.Context.User;
            jsonObject.Add(contextUser, JToken.Parse(JsonConvert.SerializeObject(scUser.DisplayName, jsettings)));

            var retUrl = Sitecore.Context.Request.QueryString["retUrl"];
            jsonObject.Add(returnUrl, JToken.Parse(JsonConvert.SerializeObject(retUrl, jsettings)));

            return jsonObject;
        }
    }
}
