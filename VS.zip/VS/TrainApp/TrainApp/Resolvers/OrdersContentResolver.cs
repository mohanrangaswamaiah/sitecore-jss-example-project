﻿using Glass.Mapper.Sc;
using Glass.Mapper.Sc.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sitecore.LayoutService.Configuration;
using Sitecore.LayoutService.ItemRendering.ContentsResolvers;

namespace TrainApp.Resolvers
{
    public class OrdersContentResolver : RenderingContentsResolver
    {
       // private readonly string InvoiceNo = "InvoiceNo";
       // private readonly string ProductName = "ProductName";
        public override object ResolveContents(Sitecore.Mvc.Presentation.Rendering rendering, IRenderingConfiguration renderingConfig)
        {
            var jsonObject = base.ProcessItem(rendering.Item, rendering, renderingConfig);
            return jsonObject;
        }
    }
}
