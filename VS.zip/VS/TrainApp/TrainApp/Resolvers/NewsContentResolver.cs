﻿using Sitecore.Diagnostics;
using Sitecore.LayoutService.Configuration;
using Sitecore.LayoutService.ItemRendering.ContentsResolvers;

namespace TrainApp.Resolvers
{
    public class NewsContentResolver : RenderingContentsResolver
    {
        public override object ResolveContents(Sitecore.Mvc.Presentation.Rendering rendering, IRenderingConfiguration renderingConfig)
        {
            Assert.ArgumentNotNull(rendering, nameof(rendering));
            Assert.ArgumentNotNull(renderingConfig, nameof(renderingConfig));

            var dataSource= !string.IsNullOrEmpty(rendering.DataSource)? rendering.RenderingItem?.Database.GetItem(rendering.DataSource): null;

            if (dataSource == null)
            {
                return null;
            }

           return base.ProcessItem(dataSource, rendering, renderingConfig);
        }
    }
}